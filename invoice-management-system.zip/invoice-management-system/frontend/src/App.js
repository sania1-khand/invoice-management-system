import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import Dashboard from './components/Dashboard';
import Customers from './components/Customers';
import Invoices from './components/Invoices';
import CreateInvoice from './components/CreateInvoice';
import InvoiceDetails from './components/InvoiceDetails';
import EditInvoice from './components/EditInvoice';
import Login from './components/Login';
import Navbar from './components/Navbar';

function App() {
  const token = localStorage.getItem('token');

  if (!token) {
    return (
      <>
        <Toaster 
          position="top-right"
          toastOptions={{
            duration: 4000,
            style: {
              background: '#363636',
              color: '#fff',
            },
            success: {
              duration: 3000,
              theme: {
                primary: 'green',
                secondary: 'black',
              },
            },
            error: {
              duration: 4000,
              theme: {
                primary: 'red',
                secondary: 'black',
              },
            },
          }}
        />
        <Login />
      </>
    );
  }

  return (
    <Router>
      <Toaster 
        position="top-right"
        toastOptions={{
          duration: 4000,
          style: {
            background: '#363636',
            color: '#fff',
          },
          success: {
            duration: 3000,
            icon: '✓',
          },
          error: {
            duration: 4000,
            icon: '✗',
          },
        }}
      />
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <Routes>
          {/* Dashboard Route */}
          <Route path="/" element={<Navigate to="/dashboard" />} />
          <Route path="/dashboard" element={<Dashboard />} />
          
          {/* Customer Routes */}
          <Route path="/customers" element={<Customers />} />
          
          {/* Invoice Routes */}
          <Route path="/invoices" element={<Invoices />} />
          <Route path="/create-invoice" element={<CreateInvoice />} />
          <Route path="/invoices/:id" element={<InvoiceDetails />} />
          <Route path="/edit-invoice/:id" element={<EditInvoice />} />
          
          {/* Fallback Route - 404 */}
          <Route path="*" element={<Navigate to="/dashboard" />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;