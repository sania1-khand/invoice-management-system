import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import { FaFileInvoice, FaMoneyBillWave, FaUsers, FaEye } from 'react-icons/fa';

const Dashboard = () => {
    const [stats, setStats] = useState({
        totalInvoices: 0,
        totalRevenue: 0,
        totalCustomers: 0
    });
    const [recentInvoices, setRecentInvoices] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchStats();
        fetchRecentInvoices();
    }, []);

    const fetchStats = async () => {
        try {
            const response = await axios.get('http://localhost:5000/api/stats');
            console.log('Stats response:', response.data); // Debug log
            
            // Safe parsing of data
            const totalInvoices = parseFloat(response.data.totalInvoices) || 0;
            const totalRevenue = parseFloat(response.data.totalRevenue) || 0;
            const totalCustomers = parseFloat(response.data.totalCustomers) || 0;
            
            setStats({
                totalInvoices: totalInvoices,
                totalRevenue: totalRevenue,
                totalCustomers: totalCustomers
            });
        } catch (error) {
            console.error('Error fetching stats:', error);
            // Set default values on error
            setStats({
                totalInvoices: 0,
                totalRevenue: 0,
                totalCustomers: 0
            });
        }
    };

    const fetchRecentInvoices = async () => {
        try {
            const response = await axios.get('http://localhost:5000/api/invoices');
            setRecentInvoices(response.data.slice(0, 5));
        } catch (error) {
            console.error('Error fetching invoices:', error);
            setRecentInvoices([]);
        } finally {
            setLoading(false);
        }
    };

    const formatCurrency = (value) => {
        // Safe currency formatting
        const num = parseFloat(value);
        if (isNaN(num)) return '0.00';
        return num.toFixed(2);
    };

    const cards = [
        { 
            title: 'Total Invoices', 
            value: stats.totalInvoices, 
            icon: FaFileInvoice, 
            color: 'bg-blue-500', 
            gradient: 'from-blue-500 to-blue-600' 
        },
        { 
            title: 'Total Revenue', 
            value: `Rs. ${formatCurrency(stats.totalRevenue)}`, 
            icon: FaMoneyBillWave, 
            color: 'bg-green-500', 
            gradient: 'from-green-500 to-green-600' 
        },
        { 
            title: 'Total Customers', 
            value: stats.totalCustomers, 
            icon: FaUsers, 
            color: 'bg-purple-500', 
            gradient: 'from-purple-500 to-purple-600' 
        },
    ];

    if (loading) {
        return (
            <div className="flex justify-center items-center h-64">
                <div className="text-center">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
                    <p className="mt-4 text-gray-600">Loading dashboard...</p>
                </div>
            </div>
        );
    }

    return (
        <div>
            <div className="mb-8">
                <h1 className="text-3xl font-bold text-gray-800">Dashboard</h1>
                <p className="text-gray-500 mt-1">Welcome back to your invoice management system</p>
            </div>
            
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                {cards.map((card, index) => (
                    <div key={index} className={`bg-gradient-to-r ${card.gradient} rounded-xl shadow-lg p-6 text-white transform hover:scale-105 transition-transform duration-300`}>
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-white text-opacity-90 text-sm">{card.title}</p>
                                <p className="text-3xl font-bold mt-2">{card.value}</p>
                            </div>
                            <div className="bg-white bg-opacity-20 p-3 rounded-full">
                                <card.icon size={28} />
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            {/* Recent Invoices */}
            <div className="bg-white rounded-xl shadow-lg overflow-hidden">
                <div className="bg-gray-50 px-6 py-4 border-b">
                    <h2 className="text-xl font-bold text-gray-800">Recent Invoices</h2>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Invoice #</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {recentInvoices.length > 0 ? (
                                recentInvoices.map((invoice) => (
                                    <tr key={invoice.id} className="hover:bg-gray-50 transition-colors">
                                        <td className="px-6 py-4 whitespace-nowrap font-medium text-gray-900">
                                            {invoice.invoice_number}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-gray-700">
                                            {invoice.customer_name}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap font-semibold text-green-600">
                                            Rs. {formatCurrency(invoice.total_amount)}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-gray-500">
                                            {new Date(invoice.created_at).toLocaleDateString()}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <Link
                                                to={`/invoices/${invoice.id}`}
                                                className="text-blue-600 hover:text-blue-800 transition-colors flex items-center gap-1"
                                            >
                                                <FaEye /> View
                                            </Link>
                                        </td>
                                    </tr>
                                ))
                            ) : (
                                <tr>
                                    <td colSpan="5" className="px-6 py-12 text-center text-gray-500">
                                        No invoices yet. Create your first invoice!
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default Dashboard;