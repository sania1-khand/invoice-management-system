import React, { useState, useEffect } from 'react';
import axios from 'axios';
import toast from 'react-hot-toast';
import { useNavigate } from 'react-router-dom';

const CreateInvoice = () => {
    const navigate = useNavigate();
    const [customers, setCustomers] = useState([]);
    const [selectedCustomer, setSelectedCustomer] = useState('');
    const [items, setItems] = useState([
        { item_name: '', quantity: 1, price: 0 }
    ]);

    useEffect(() => {
        fetchCustomers();
    }, []);

    const fetchCustomers = async () => {
        try {
            const response = await axios.get('http://localhost:5000/api/customers');
            setCustomers(response.data);
        } catch (error) {
            toast.error('Failed to fetch customers');
        }
    };

    const addItem = () => {
        setItems([...items, { item_name: '', quantity: 1, price: 0 }]);
    };

    const removeItem = (index) => {
        const newItems = items.filter((_, i) => i !== index);
        setItems(newItems);
    };

    const updateItem = (index, field, value) => {
        const newItems = [...items];
        newItems[index][field] = value;
        setItems(newItems);
    };

    const calculateTotal = () => {
        return items.reduce((sum, item) => sum + (item.quantity * item.price), 0);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        if (!selectedCustomer) {
            toast.error('Please select a customer');
            return;
        }

        if (items.some(item => !item.item_name || item.quantity <= 0 || item.price <= 0)) {
            toast.error('Please fill all item fields correctly');
            return;
        }

        try {
            const response = await axios.post('http://localhost:5000/api/invoices', {
                customer_id: selectedCustomer,
                items: items
            });
            toast.success('Invoice created successfully!');
            navigate('/invoices');
        } catch (error) {
            toast.error('Failed to create invoice');
        }
    };

    return (
        <div className="max-w-4xl mx-auto">
            <h1 className="text-3xl font-bold mb-6">Create New Invoice</h1>
            
            <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-md p-6">
                {/* Customer Selection */}
                <div className="mb-6">
                    <label className="block text-gray-700 mb-2 font-semibold">Select Customer</label>
                    <select
                        value={selectedCustomer}
                        onChange={(e) => setSelectedCustomer(e.target.value)}
                        className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                    >
                        <option value="">Choose a customer...</option>
                        {customers.map(customer => (
                            <option key={customer.id} value={customer.id}>
                                {customer.name} - {customer.email}
                            </option>
                        ))}
                    </select>
                </div>

                {/* Invoice Items */}
                <div className="mb-6">
                    <label className="block text-gray-700 mb-2 font-semibold">Invoice Items</label>
                    <div className="space-y-4">
                        {items.map((item, index) => (
                            <div key={index} className="grid grid-cols-12 gap-3 items-center">
                                <input
                                    type="text"
                                    placeholder="Item name"
                                    value={item.item_name}
                                    onChange={(e) => updateItem(index, 'item_name', e.target.value)}
                                    className="col-span-5 px-3 py-2 border rounded-lg"
                                    required
                                />
                                <input
                                    type="number"
                                    placeholder="Qty"
                                    value={item.quantity}
                                    onChange={(e) => updateItem(index, 'quantity', parseInt(e.target.value))}
                                    className="col-span-2 px-3 py-2 border rounded-lg"
                                    min="1"
                                    required
                                />
                                <input
                                    type="number"
                                    placeholder="Price"
                                    value={item.price}
                                    onChange={(e) => updateItem(index, 'price', parseFloat(e.target.value))}
                                    className="col-span-3 px-3 py-2 border rounded-lg"
                                    min="0"
                                    step="0.01"
                                    required
                                />
                                <div className="col-span-1 text-right font-semibold">
                                    Rs. {(item.quantity * item.price).toFixed(2)}
                                </div>
                                <button
                                    type="button"
                                    onClick={() => removeItem(index)}
                                    className="col-span-1 text-red-600 hover:text-red-800"
                                    disabled={items.length === 1}
                                >
                                    Remove
                                </button>
                            </div>
                        ))}
                    </div>
                    
                    <button
                        type="button"
                        onClick={addItem}
                        className="mt-3 text-blue-600 hover:text-blue-800"
                    >
                        + Add Item
                    </button>
                </div>

                {/* Total Amount */}
                <div className="border-t pt-4 mb-6">
                    <div className="text-right">
                        <span className="text-xl font-bold">Total Amount: </span>
                        <span className="text-2xl font-bold text-green-600">
                            Rs. {calculateTotal().toFixed(2)}
                        </span>
                    </div>
                </div>

                {/* Submit Button */}
                <div className="flex gap-3">
                    <button
                        type="submit"
                        className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700"
                    >
                        Create Invoice
                    </button>
                    <button
                        type="button"
                        onClick={() => navigate('/invoices')}
                        className="bg-gray-500 text-white px-6 py-2 rounded-lg hover:bg-gray-600"
                    >
                        Cancel
                    </button>
                </div>
            </form>
        </div>
    );
};

export default CreateInvoice;