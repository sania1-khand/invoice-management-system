import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import toast from 'react-hot-toast';
import { FaPlus, FaTrash, FaSave, FaTimes } from 'react-icons/fa';

const EditInvoice = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [customers, setCustomers] = useState([]);
    const [selectedCustomer, setSelectedCustomer] = useState('');
    const [items, setItems] = useState([{ item_name: '', quantity: 1, price: 0 }]);
    const [loading, setLoading] = useState(true);
    const [updating, setUpdating] = useState(false);

    useEffect(() => {
        fetchData();
    }, [id]);

    const fetchData = async () => {
        try {
            const [customersRes, invoiceRes] = await Promise.all([
                axios.get('http://localhost:5000/api/customers'),
                axios.get(`http://localhost:5000/api/invoices/${id}`)
            ]);
            
            setCustomers(customersRes.data);
            const invoice = invoiceRes.data;
            setSelectedCustomer(invoice.customer_id);
            setItems(invoice.items.map(item => ({
                item_name: item.item_name,
                quantity: parseInt(item.quantity),
                price: parseFloat(item.price)
            })));
        } catch (error) {
            toast.error('Failed to load invoice');
            navigate('/invoices');
        } finally {
            setLoading(false);
        }
    };

    const addItem = () => {
        setItems([...items, { item_name: '', quantity: 1, price: 0 }]);
    };

    const removeItem = (index) => {
        const newItems = items.filter((_, i) => i !== index);
        setItems(newItems);
    };

    const updateItem = (index, field, value) => {
        const newItems = [...items];
        newItems[index][field] = field === 'price' || field === 'quantity' ? parseFloat(value) || 0 : value;
        setItems(newItems);
    };

    const calculateTotal = () => {
        return items.reduce((sum, item) => sum + (item.quantity * (item.price || 0)), 0);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        if (!selectedCustomer) {
            toast.error('Please select a customer');
            return;
        }

        if (items.some(item => !item.item_name || item.quantity <= 0 || item.price <= 0)) {
            toast.error('Please fill all item fields correctly');
            return;
        }

        setUpdating(true);
        try {
            await axios.put(`http://localhost:5000/api/invoices/${id}`, {
                customer_id: selectedCustomer,
                items: items
            });
            toast.success('Invoice updated successfully!');
            navigate('/invoices');
        } catch (error) {
            toast.error('Failed to update invoice');
        } finally {
            setUpdating(false);
        }
    };

    const formatCurrency = (value) => {
        const num = parseFloat(value);
        return isNaN(num) ? '0.00' : num.toFixed(2);
    };

    if (loading) {
        return (
            <div className="flex justify-center items-center h-64">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
            </div>
        );
    }

    return (
        <div className="max-w-4xl mx-auto">
            <div className="mb-6">
                <h1 className="text-3xl font-bold text-gray-800">Edit Invoice #{id}</h1>
                <p className="text-gray-500 mt-1">Update invoice details</p>
            </div>
            
            <form onSubmit={handleSubmit} className="bg-white rounded-xl shadow-lg p-6">
                {/* Customer Selection */}
                <div className="mb-6">
                    <label className="block text-gray-700 mb-2 font-semibold">Select Customer</label>
                    <select
                        value={selectedCustomer}
                        onChange={(e) => setSelectedCustomer(e.target.value)}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                    >
                        <option value="">Choose a customer...</option>
                        {customers.map(customer => (
                            <option key={customer.id} value={customer.id}>
                                {customer.name} - {customer.email}
                            </option>
                        ))}
                    </select>
                </div>

                {/* Invoice Items */}
                <div className="mb-6">
                    <label className="block text-gray-700 mb-2 font-semibold">Invoice Items</label>
                    <div className="space-y-3">
                        {items.map((item, index) => (
                            <div key={index} className="grid grid-cols-12 gap-3 items-center">
                                <input
                                    type="text"
                                    placeholder="Item name"
                                    value={item.item_name}
                                    onChange={(e) => updateItem(index, 'item_name', e.target.value)}
                                    className="col-span-5 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    required
                                />
                                <input
                                    type="number"
                                    placeholder="Qty"
                                    value={item.quantity}
                                    onChange={(e) => updateItem(index, 'quantity', e.target.value)}
                                    className="col-span-2 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    min="1"
                                    required
                                />
                                <input
                                    type="number"
                                    placeholder="Price"
                                    value={item.price}
                                    onChange={(e) => updateItem(index, 'price', e.target.value)}
                                    className="col-span-3 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    min="0"
                                    step="0.01"
                                    required
                                />
                                <div className="col-span-1 text-right font-semibold text-gray-700">
                                    Rs. {formatCurrency(item.quantity * item.price)}
                                </div>
                                <button
                                    type="button"
                                    onClick={() => removeItem(index)}
                                    className="col-span-1 text-red-600 hover:text-red-800"
                                    disabled={items.length === 1}
                                >
                                    <FaTrash />
                                </button>
                            </div>
                        ))}
                    </div>
                    
                    <button
                        type="button"
                        onClick={addItem}
                        className="mt-3 text-blue-600 hover:text-blue-800 flex items-center gap-1"
                    >
                        <FaPlus size={12} /> Add Item
                    </button>
                </div>

                {/* Total Amount */}
                <div className="border-t pt-4 mb-6">
                    <div className="text-right">
                        <span className="text-xl font-bold text-gray-800">Total Amount: </span>
                        <span className="text-2xl font-bold text-green-600">
                            Rs. {formatCurrency(calculateTotal())}
                        </span>
                    </div>
                </div>

                {/* Buttons */}
                <div className="flex gap-3">
                    <button
                        type="submit"
                        disabled={updating}
                        className="flex-1 bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
                    >
                        <FaSave /> {updating ? 'Updating...' : 'Update Invoice'}
                    </button>
                    <button
                        type="button"
                        onClick={() => navigate('/invoices')}
                        className="flex-1 bg-gray-500 text-white py-2 rounded-lg hover:bg-gray-600 transition-colors flex items-center justify-center gap-2"
                    >
                        <FaTimes /> Cancel
                    </button>
                </div>
            </form>
        </div>
    );
};

export default EditInvoice;