import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import toast from 'react-hot-toast';
import { FaArrowLeft, FaEdit, FaDownload, FaPrint } from 'react-icons/fa';

// PDF imports - Fixed way
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

const InvoiceDetails = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [invoice, setInvoice] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchInvoice();
    }, [id]);

    const fetchInvoice = async () => {
        try {
            const response = await axios.get(`http://localhost:5000/api/invoices/${id}`);
            setInvoice(response.data);
        } catch (error) {
            toast.error('Failed to fetch invoice');
            navigate('/invoices');
        } finally {
            setLoading(false);
        }
    };

    const formatCurrency = (value) => {
        const num = parseFloat(value);
        return isNaN(num) ? '0.00' : num.toFixed(2);
    };

    const downloadPDF = () => {
        try {
            // Create new PDF document
            const doc = new jsPDF();
            
            // Header
            doc.setFontSize(20);
            doc.setTextColor(40, 40, 40);
            doc.text('INVOICE', 105, 20, { align: 'center' });
            
            // Invoice Info
            doc.setFontSize(10);
            doc.setTextColor(100, 100, 100);
            doc.text(`Invoice #: ${invoice.invoice_number}`, 20, 40);
            doc.text(`Date: ${new Date(invoice.created_at).toLocaleDateString()}`, 20, 45);
            
            // Customer Info
            doc.setFontSize(12);
            doc.setTextColor(40, 40, 40);
            doc.text('Bill To:', 20, 60);
            doc.setFontSize(10);
            doc.text(invoice.customer_name, 20, 68);
            doc.text(invoice.email, 20, 73);
            doc.text(invoice.phone, 20, 78);
            
            // Items Table
            const tableData = invoice.items.map(item => [
                item.item_name,
                item.quantity.toString(),
                `Rs. ${formatCurrency(item.price)}`,
                `Rs. ${formatCurrency(item.total)}`
            ]);
            
            // Use autoTable correctly
            autoTable(doc, {
                startY: 90,
                head: [['Item Name', 'Quantity', 'Unit Price', 'Total']],
                body: tableData,
                theme: 'striped',
                headStyles: { 
                    fillColor: [59, 130, 246],
                    textColor: [255, 255, 255],
                    fontStyle: 'bold'
                },
                alternateRowStyles: { fillColor: [240, 240, 240] },
                margin: { left: 20, right: 20 }
            });
            
            // Get final Y position
            const finalY = doc.lastAutoTable?.finalY || 150;
            
            // Total
            doc.setFontSize(12);
            doc.setTextColor(40, 40, 40);
            doc.text(`Grand Total:`, 130, finalY + 10);
            doc.setFontSize(14);
            doc.setTextColor(34, 197, 94);
            doc.text(`Rs. ${formatCurrency(invoice.total_amount)}`, 130, finalY + 20);
            
            // Footer
            doc.setFontSize(8);
            doc.setTextColor(150, 150, 150);
            doc.text('Thank you for your business!', 105, 280, { align: 'center' });
            
            // Save PDF
            doc.save(`Invoice_${invoice.invoice_number}.pdf`);
            toast.success('PDF downloaded successfully!');
        } catch (error) {
            console.error('PDF Error:', error);
            toast.error('Failed to generate PDF');
        }
    };

    const handlePrint = () => {
        window.print();
    };

    if (loading) {
        return (
            <div className="flex justify-center items-center h-64">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
            </div>
        );
    }

    if (!invoice) {
        return (
            <div className="text-center py-8">
                <p className="text-gray-600">Invoice not found</p>
                <button 
                    onClick={() => navigate('/invoices')} 
                    className="mt-4 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
                >
                    Back to Invoices
                </button>
            </div>
        );
    }

    return (
        <div className="max-w-4xl mx-auto">
            <div className="bg-white rounded-xl shadow-lg overflow-hidden">
                {/* Header */}
                <div className="bg-gradient-to-r from-blue-600 to-blue-800 px-8 py-6 text-white">
                    <div className="flex justify-between items-start">
                        <div>
                            <h1 className="text-3xl font-bold">INVOICE</h1>
                            <p className="text-blue-100 mt-1">#{invoice.invoice_number}</p>
                        </div>
                        <div className="text-right">
                            <p className="text-sm text-blue-100">
                                Date: {new Date(invoice.created_at).toLocaleDateString()}
                            </p>
                        </div>
                    </div>
                </div>

                <div className="p-8">
                    {/* Customer Info */}
                    <div className="mb-8">
                        <h2 className="text-lg font-semibold text-gray-800 mb-3">Bill To:</h2>
                        <div className="bg-gray-50 p-4 rounded-lg">
                            <p className="font-medium text-gray-800">{invoice.customer_name}</p>
                            <p className="text-gray-600">{invoice.email}</p>
                            <p className="text-gray-600">{invoice.phone}</p>
                        </div>
                    </div>

                    {/* Items Table */}
                    <div className="mb-8 overflow-x-auto">
                        <table className="w-full">
                            <thead className="bg-gray-50">
                                <tr>
                                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Item</th>
                                    <th className="px-4 py-3 text-center text-sm font-semibold text-gray-700">Quantity</th>
                                    <th className="px-4 py-3 text-right text-sm font-semibold text-gray-700">Price</th>
                                    <th className="px-4 py-3 text-right text-sm font-semibold text-gray-700">Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                {invoice.items && invoice.items.map((item, index) => (
                                    <tr key={index} className="border-t border-gray-200">
                                        <td className="px-4 py-3 text-gray-800">{item.item_name}</td>
                                        <td className="px-4 py-3 text-center text-gray-800">{item.quantity}</td>
                                        <td className="px-4 py-3 text-right text-gray-800">Rs. {formatCurrency(item.price)}</td>
                                        <td className="px-4 py-3 text-right text-gray-800">Rs. {formatCurrency(item.total)}</td>
                                    </tr>
                                ))}
                            </tbody>
                            <tfoot className="border-t-2 border-gray-300">
                                <tr>
                                    <td colSpan="3" className="px-4 py-3 text-right font-bold text-gray-800">Grand Total:</td>
                                    <td className="px-4 py-3 text-right font-bold text-green-600 text-lg">
                                        Rs. {formatCurrency(invoice.total_amount)}
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>

                    {/* Buttons */}
                    <div className="flex flex-wrap gap-3">
                        <button
                            onClick={() => navigate('/invoices')}
                            className="bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600 transition-colors flex items-center gap-2"
                        >
                            <FaArrowLeft /> Back
                        </button>
                        <button
                            onClick={() => navigate(`/edit-invoice/${id}`)}
                            className="bg-yellow-500 text-white px-4 py-2 rounded-lg hover:bg-yellow-600 transition-colors flex items-center gap-2"
                        >
                            <FaEdit /> Edit
                        </button>
                        <button
                            onClick={downloadPDF}
                            className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2"
                        >
                            <FaDownload /> PDF
                        </button>
                        <button
                            onClick={handlePrint}
                            className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors flex items-center gap-2"
                        >
                            <FaPrint /> Print
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default InvoiceDetails;