import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { FaTachometerAlt, FaUsers, FaFileInvoice, FaSignOutAlt } from 'react-icons/fa';
import toast from 'react-hot-toast';

const Navbar = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('username');
    toast.success('Logged out successfully');
    navigate('/');
    window.location.reload();
  };

  return (
    <nav className="bg-blue-600 text-white shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          <div className="text-xl font-bold">Invoice System</div>
          <div className="flex space-x-6">
            <Link to="/dashboard" className="flex items-center space-x-2 hover:text-blue-200">
              <FaTachometerAlt />
              <span>Dashboard</span>
            </Link>
            <Link to="/customers" className="flex items-center space-x-2 hover:text-blue-200">
              <FaUsers />
              <span>Customers</span>
            </Link>
            <Link to="/invoices" className="flex items-center space-x-2 hover:text-blue-200">
              <FaFileInvoice />
              <span>Invoices</span>
            </Link>
            <button onClick={handleLogout} className="flex items-center space-x-2 hover:text-blue-200">
              <FaSignOutAlt />
              <span>Logout</span>
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;