const express = require("express");
const cors = require("cors");
const mysql = require("mysql2");
require("dotenv").config();

const app = express();

app.use(cors());
app.use(express.json());

// MySQL Connection
const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",  // XAMPP mein password khali hai
    database: "invoice_system"
});

db.connect((err) => {
    if (err) {
        console.error("❌ Database connection failed:", err);
    } else {
        console.log("✅ MySQL Connected successfully!");
    }
});

// ---------------------- CUSTOMER APIs ----------------------

// Get all customers
app.get("/api/customers", (req, res) => {
    db.query("SELECT * FROM customers ORDER BY created_at DESC", (err, result) => {
        if (err) throw err;
        res.json(result);
    });
});

// Add customer
app.post("/api/customers", (req, res) => {
    const { name, email, phone } = req.body;
    db.query(
        "INSERT INTO customers (name, email, phone) VALUES (?, ?, ?)",
        [name, email, phone],
        (err, result) => {
            if (err) {
                res.status(500).json({ error: err.message });
                return;
            }
            res.json({ id: result.insertId, name, email, phone });
        }
    );
});

// Delete customer
app.delete("/api/customers/:id", (req, res) => {
    db.query("DELETE FROM customers WHERE id = ?", [req.params.id], (err) => {
        if (err) throw err;
        res.json({ message: "Customer deleted successfully" });
    });
});

// ---------------------- INVOICE APIs ----------------------

// Generate invoice number
function generateInvoiceNumber() {
    return 'INV-' + Date.now();
}

// Create new invoice
app.post("/api/invoices", (req, res) => {
    const { customer_id, items } = req.body;
    const invoice_number = generateInvoiceNumber();
    const total_amount = items.reduce((sum, item) => sum + (item.quantity * item.price), 0);

    db.query(
        "INSERT INTO invoices (invoice_number, customer_id, total_amount) VALUES (?, ?, ?)",
        [invoice_number, customer_id, total_amount],
        (err, result) => {
            if (err) {
                res.status(500).json({ error: err.message });
                return;
            }

            const invoice_id = result.insertId;
            let itemsInserted = 0;

            items.forEach(item => {
                const itemTotal = item.quantity * item.price;
                db.query(
                    "INSERT INTO invoice_items (invoice_id, item_name, quantity, price, total) VALUES (?, ?, ?, ?, ?)",
                    [invoice_id, item.item_name, item.quantity, item.price, itemTotal],
                    (err) => {
                        if (err) throw err;
                        itemsInserted++;
                        
                        if (itemsInserted === items.length) {
                            res.json({
                                id: invoice_id,
                                invoice_number,
                                customer_id,
                                total_amount,
                                items
                            });
                        }
                    }
                );
            });
        }
    );
});

// Get all invoices with customer names
app.get("/api/invoices", (req, res) => {
    const sql = `
        SELECT i.*, c.name as customer_name 
        FROM invoices i 
        JOIN customers c ON i.customer_id = c.id 
        ORDER BY i.created_at DESC
    `;
    db.query(sql, (err, invoices) => {
        if (err) throw err;
        
        if (invoices.length === 0) {
            return res.json([]);
        }
        
        let invoicesProcessed = 0;
        const result = [];
        
        invoices.forEach(invoice => {
            db.query("SELECT * FROM invoice_items WHERE invoice_id = ?", [invoice.id], (err, items) => {
                if (err) throw err;
                invoice.items = items;
                result.push(invoice);
                invoicesProcessed++;
                
                if (invoicesProcessed === invoices.length) {
                    res.json(result);
                }
            });
        });
    });
});

// Get single invoice with details
app.get("/api/invoices/:id", (req, res) => {
    const invoiceId = req.params.id;
    
    db.query(
        "SELECT i.*, c.name as customer_name, c.email, c.phone FROM invoices i JOIN customers c ON i.customer_id = c.id WHERE i.id = ?",
        [invoiceId],
        (err, invoice) => {
            if (err) throw err;
            if (invoice.length === 0) {
                return res.status(404).json({ message: "Invoice not found" });
            }
            
            db.query("SELECT * FROM invoice_items WHERE invoice_id = ?", [invoiceId], (err, items) => {
                if (err) throw err;
                res.json({ ...invoice[0], items });
            });
        }
    );
});

// Update/Edit invoice
app.put("/api/invoices/:id", (req, res) => {
    const invoiceId = req.params.id;
    const { customer_id, items } = req.body;
    const total_amount = items.reduce((sum, item) => sum + (item.quantity * item.price), 0);

    // Update invoice
    db.query(
        "UPDATE invoices SET customer_id = ?, total_amount = ? WHERE id = ?",
        [customer_id, total_amount, invoiceId],
        (err) => {
            if (err) {
                res.status(500).json({ error: err.message });
                return;
            }

            // Delete old items
            db.query("DELETE FROM invoice_items WHERE invoice_id = ?", [invoiceId], (err) => {
                if (err) throw err;

                // Insert new items
                let itemsInserted = 0;
                items.forEach(item => {
                    const itemTotal = item.quantity * item.price;
                    db.query(
                        "INSERT INTO invoice_items (invoice_id, item_name, quantity, price, total) VALUES (?, ?, ?, ?, ?)",
                        [invoiceId, item.item_name, item.quantity, item.price, itemTotal],
                        (err) => {
                            if (err) throw err;
                            itemsInserted++;
                            
                            if (itemsInserted === items.length) {
                                res.json({ message: "Invoice updated successfully" });
                            }
                        }
                    );
                });
            });
        }
    );
});

// Delete invoice
app.delete("/api/invoices/:id", (req, res) => {
    db.query("DELETE FROM invoices WHERE id = ?", [req.params.id], (err) => {
        if (err) throw err;
        res.json({ message: "Invoice deleted successfully" });
    });
});

// Dashboard stats
app.get("/api/stats", (req, res) => {
    const stats = {};
    
    db.query("SELECT COUNT(*) as total FROM invoices", (err, invoiceCount) => {
        if (err) throw err;
        stats.totalInvoices = invoiceCount[0].total;
        
        db.query("SELECT COALESCE(SUM(total_amount), 0) as total FROM invoices", (err, revenue) => {
            if (err) throw err;
            stats.totalRevenue = revenue[0].total;
            
            db.query("SELECT COUNT(*) as total FROM customers", (err, customerCount) => {
                if (err) throw err;
                stats.totalCustomers = customerCount[0].total;
                res.json(stats);
            });
        });
    });
});

// ---------------------- TEST ROUTE ----------------------
app.get("/", (req, res) => {
    res.json({ message: "Invoice API Running with MySQL!" });
});

// ---------------------- SERVER START ----------------------
const PORT = 5000;
app.listen(PORT, () => {
    console.log(`🚀 Server running on port ${PORT}`);
    console.log(`📝 API URL: http://localhost:${PORT}`);
    console.log(`👥 Customers: http://localhost:${PORT}/api/customers`);
    console.log(`📄 Invoices: http://localhost:${PORT}/api/invoices`);
    console.log(`✅ MySQL Database Connected`);
});